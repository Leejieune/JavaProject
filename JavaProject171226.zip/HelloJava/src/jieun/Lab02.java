package jieun;

public class Lab02 {
	public static void main(String[] args) {
		// 2
		String name = "leejieun";
		int cm = 165;
		int age = 24;
		System.out.printf("이름 : %s,키 : %d, 나이 : %d", name, cm, age);

	}

}
