package jieun;

//클래스 이름과 파일이름은 동일해야함
//클래스 이름은 대문자로 작성할 것!
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello, World!!");
		// System.out.println();
	}
}

// 파일안에 2개 이상의 클래스를 정의 하는 경우
// 2번째 클래스부터는 public 접근제한자를
// 제외하고 작성한다
class HelloAnotherWorld {

}