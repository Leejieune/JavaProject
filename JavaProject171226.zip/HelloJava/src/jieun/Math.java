package jieun;

public class Math {
	public static void main(String[] args) {
		// Math:수학관련클래스
		// cell(),round(),floor()

		// Random :난수생성클래스
		// nextInt(숫자n): 0~(n-1)까지의 난수 생성

	}

	public static double random() {
		// TODO Auto-generated method stub
		return 0;
	}
}