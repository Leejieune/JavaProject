package jieun.lab;

public class Lab12 {
	public static void main(String[] args) {
		// 고객 , 도서, 주문 , 학생 , 학과, 과목, 교수
		//
		// Customer c = new Customer();
		// c.cno = "1";
		// c.name = "박지성";
		// c.jumin = "810101-111111";
		// c.addr = "영국 런던";
		// c.phone = "010-4456-7175";
		//
		// c = new Customer("1", "박지성", "810101-1111111", "영국런던", "010-4456-7175");
		// System.out.println(c.name);
		// System.out.println(c.jumin);
		//
		// Book b = new Book();
		// b.bno = "1";
		// b.name = "축구의 역사";
		// b.publisher = "굿스포츠";
		// b.price = "7000";
		//
		// b = new Book("1", "축구의 역사", "굿스포츠", "7000");
		// System.out.println(b.name);
		// System.out.println(b.price);
		//
		// Order o = new Order();
		// o.cno = "1";
		// o.bno = "1";
		// o.price = "7000";
		// o.date = "2014-07-01";
		// o = new Order("1", "1", "7000", "2014-07-01");
		// System.out.println(o.cno);
		// System.out.println(o.date);
		//
		// Student s = new Student();
		// s.code = "20135050";
		// s.name = "김태희";
		// s.addr = "경기도 고양시";
		// s.age = 25;
		// s.birth = "1985.03.22";
		// s.major = "컴퓨터공학";
		// s.professor = "504";
		// s.mhour = "목 2교시";
		//
		// s = new Student("20134050", "김태희", "경기도 고양시", 25, "1985.03.02", "컴공", "504",
		// "목2교시");
		// System.out.println(s.code);
		// System.out.println(s.age);
		//
		// Major m = new Major();
		// m.major = "컴퓨터공학";
		// m.phone = "123-4567-8901";
		// m.location = "E동 2층";
		// m.date = "2007";
		//
		// m = new Major("컴공", "123424", "E동2층", "2007");
		// System.out.println(m.major);
		// System.out.println(m.date);
		// System.out.println(m.location);
		//
		// Subject sb = new Subject();
		// sb.num = "0205";
		// sb.subject = "프로그래밍";
		// sb.department = "자바 프로그래밍";
		// sb.classnum = "301";
		//
		// Professor p = new Professor();
		// p.num = "301";
		// p.name = "이순신";
		// p.major = "프로그래밍";
		// }
		//
		// }
		//
		//// Animal(String name, int weight, String gender, String type) {
		//// this.name = name;
		//// this.weight = weight;
		//// this.gender = gender;
		//// this.type = type;
		// class Customer {
		// String cno;
		// String name;
		// String jumin;
		// String addr;
		// String phone;
		//
		// Customer(String cno, String name, String jumin, String addr, String phone) {
		// this.cno = cno;
		// this.name = name;
		// this.jumin = jumin;
		// this.addr = addr;
		// this.phone = phone;
		// }
		//
		// public Customer() {
		// // TODO Auto-generated constructor stub
		// }
		//
		// }
		//
		// class Book {
		// String bno;
		// String name;
		// String publisher;
		// String price;
		//
		// Book(String bno, String name, String publisher, String price) {
		// this.bno = bno;
		// this.name = name;
		// this.publisher = publisher;
		// this.price = price;
		//
		// }
		//
		// public Book() {
		// // TODO Auto-generated constructor stub
		// }
		// }
		//
		// class Order {
		// String cno;
		// String bno;
		// String price;
		// String date;
		//
		// Order(String a, String b, String c, String d) {
		// cno = a;
		// bno = b;
		// price = c;
		// date = d;
		// }
		//
		// public Order() {
		// // TODO Auto-generated constructor stub
		// }
		// }
		//
		// class Student {
		// String code;
		// String name;
		// String addr;
		// int age;
		// String birth;
		// String major;
		// String professor;
		// String mhour;
		//
		// Student(String code, String name, String addr, int age, String birth, String
		// major, String professor,
		// String mhour) {
		// this.code = code;
		// this.name = name;
		// this.addr = addr;
		// this.age = age;
		// this.birth = birth;
		// this.major = major;
		// this.professor = professor;
		// this.mhour = mhour;
		//
		// }
		//
		// public Student() {
		// // TODO Auto-generated constructor stub
		// }
		//
		// }
		//
		// class Major {
		// String major;
		// String phone;
		// String location;
		// String date;
		//
		// Major(String m, String p, String l, String d) {
		// major = m;
		// phone = p;
		// location = l;
		// date = d;
		// }
		//
		// public Major() {
		// // TODO Auto-generated constructor stub
		// }
		// }
		//
		// class Subject {
		// String num;
		// String subject;
		// String department;
		// String classnum;
		// }
		//
		// class Professor {
		// String num;
		// String name;
		// String major;
	}
}