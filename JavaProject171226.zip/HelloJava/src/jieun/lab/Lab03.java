package jieun.lab;

public class Lab03 {
	public static void main(String[] args) {
		// 변수이름 짓기 예제
		// # 1. 축구선수
		String player; // 선수
		String team; // 팀명
		String region; // 연고지
		String position;// 포지션
		String backNo; // 등번호
		String birth; // 생년월일
		String height; // 키
		String weight; // 몸무게

		// # 2. 고객
		String number; // 번호
		String name; // 이름
		String jumin;// 주민번호
		String address; // 주소
		String phone; // 핸드폰

		// #3. 도서
		String num;
		String bookName;
		String publisher; // 출판사
		String cash; // 가격

		// #4 주문
		String customerNo; // 고객번호
		String bookNo; // 책번호
		String cash2; // 판매가격
		String date; // 주문일자

		// zz
		String region1;
		String branch;
		String director;
		String date1;
		String sell;

	}
}
