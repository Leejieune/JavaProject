package jieun.lab;

public class Lab01 {
	public static void main(String[] args) {
		// HARRY출력
		System.out.println("*   *     **    ****    ****     *   *		  /////   ");
		System.out.println("*   *    *  *   *   *   *   *    *   *		 | O O |  ");
		System.out.println("*****   *    *  ****    ****      * * 		(|  ∧  |) ");
		System.out.println("*   *   ******  *   *   *   *      *  		 | [_} |  ");
		System.out.println("*   *   *    *  *    *  *    *     *  		 -------  ");

		System.out.println("            +---+                              ");
		System.out.println("            |   |                              ");
		System.out.println("        +---+---+                              ");
		System.out.println("        |   |   |                             ");
		System.out.println("    +---+---+---+      /\\ _/\\                             -----    ");
		System.out.println("    |   |   |   |     ( ' ' )       / Hello \\    ");
		System.out.println("+---+---+---+---+     (  -  )      <  Junior | ");
		System.out.println("|   |   |   |   |      | | |        \\ Coder!/   ");
		System.out.println("+---+---+---+---+     (__|__)         -----    ");

		// [2-5] 다음 문장들의 출력결과를 적으세요. 오류가 있는 문장의 경우, 괄호 안에 ‘오
		// 류’라고 적으시오.
		// System.out.println(“1” + “2”)
		// System.out.println(true + “”)
		// System.out.println(‘A' + 'B')
		// System.out.println('1' + 2)
		// System.out.println('1' + '2')
		// System.out.println('J' + “ava”)
		// System.out.println(true + null)

	}
}