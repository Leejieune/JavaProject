package jieun.lab;

public class sungjuk2 {

}
